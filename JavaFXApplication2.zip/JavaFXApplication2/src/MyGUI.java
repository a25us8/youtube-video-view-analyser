import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class MyGUI extends Application {

    private TextField nameField;
    private Label greetingLabel;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("My GUI");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(5);
        grid.setHgap(5);

        Label nameLabel = new Label("Name:");
        GridPane.setConstraints(nameLabel, 0, 0);
        nameField = new TextField();
        GridPane.setConstraints(nameField, 1, 0);

        Button submitButton = new Button("Submit");
        GridPane.setConstraints(submitButton, 2, 0);

        greetingLabel = new Label();
        GridPane.setConstraints(greetingLabel, 0, 1, 3, 1);

        grid.getChildren().addAll(nameLabel, nameField, submitButton, greetingLabel);

        Scene scene = new Scene(grid, 300, 100);
        primaryStage.setScene(scene);
        primaryStage.show();

        submitButton.setOnAction(event -> {
            String name = nameField.getText();
            greetingLabel.setText("Hello, " + name + "!");
        });
    }

    public static void main(String[] args) {
        launch(args);
    }
}