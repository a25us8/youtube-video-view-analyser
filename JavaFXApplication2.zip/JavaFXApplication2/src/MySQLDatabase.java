import java.sql.*;

public class MySQLDatabase {

    private Connection conn;

    public MySQLDatabase() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/mydatabase?useSSL=false&serverTimezone=UTC";
            String username = "root";
            String password = "root";
            conn = DriverManager.getConnection(url, username, password);
        } catch (ClassNotFoundException | SQLException e) {
        }
    }

    public void close() {
        try {
            conn.close();
        } catch (SQLException e) {
        }
    }

    public void createTable() {
        try {
            Statement stmt = conn.createStatement();
            String sql = "CREATE TABLE IF NOT EXISTS users (id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(50), email VARCHAR(50))";
            stmt.executeUpdate(sql);
        } catch (SQLException e) {
        }
    }

    public void insert(String name, String email) {
        try {
            PreparedStatement pstmt = conn.prepareStatement("INSERT INTO users (name, email) VALUES (?, ?)");
            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.executeUpdate();
        } catch (SQLException e) {
        }
    }

    public ResultSet select() {
        ResultSet rs = null;
        try {
            Statement stmt = conn.createStatement();
            String sql = "SELECT * FROM users";
            rs = stmt.executeQuery(sql);
        } catch (SQLException e) {
        }
        return rs;
    }

    public void update(int id, String name, String email) {
        try {
            PreparedStatement pstmt = conn.prepareStatement("UPDATE users SET name=?, email=? WHERE id=?");
            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setInt(3, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
        }
    }

    public void delete(int id) {
        try {
            PreparedStatement pstmt = conn.prepareStatement("DELETE FROM users WHERE id=?");
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
        }
    }
}